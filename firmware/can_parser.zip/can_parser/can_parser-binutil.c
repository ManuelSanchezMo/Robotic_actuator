#include "can_parser-binutil.h"

#ifdef __DEF_CAN_PARSER__

can_parser_rx_t can_parser_rx;

#endif // __DEF_CAN_PARSER__

uint32_t can_parser_Receive(can_parser_rx_t* _m, const uint8_t* _d, uint32_t _id, uint8_t dlc_)
{
 uint32_t recid = 0;
 if ((_id >= 0x1U) && (_id < 0x4U)) {
  if (_id == 0x1U) {
   recid = Unpack_CONFIG_1_can_parser(&(_m->CONFIG_1), _d, dlc_);
  } else {
   if (_id == 0x2U) {
    recid = Unpack_CONFIG_2_can_parser(&(_m->CONFIG_2), _d, dlc_);
   } else if (_id == 0x3U) {
    recid = Unpack_CONFIG_3_can_parser(&(_m->CONFIG_3), _d, dlc_);
   }
  }
 } else {
  if ((_id >= 0x4U) && (_id < 0x7U)) {
   if (_id == 0x4U) {
    recid = Unpack_MOTOR_OUT_ELEC_can_parser(&(_m->MOTOR_OUT_ELEC), _d, dlc_);
   } else if (_id == 0x5U) {
    recid = Unpack_MOTOR_OUT_MEC_can_parser(&(_m->MOTOR_OUT_MEC), _d, dlc_);
   }
  } else {
   if (_id == 0x7U) {
    recid = Unpack_TRANSITION_can_parser(&(_m->TRANSITION), _d, dlc_);
   } else if (_id == 0x7U) {
    recid = Unpack_MOTOR_ANGLE_SP_can_parser(&(_m->MOTOR_ANGLE_SP), _d, dlc_);
   }
  }
 }

 return recid;
}

