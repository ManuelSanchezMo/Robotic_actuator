#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "dbccodeconf.h"

#include "can_parser.h"

// This version definition comes from main driver version and
// can be compared in user code space for strict compatibility test
#define VER_CAN_PARSER_MAJ (0U)
#define VER_CAN_PARSER_MIN (0U)

typedef struct
{
  CONFIG_1_t CONFIG_1;
  CONFIG_2_t CONFIG_2;
  CONFIG_3_t CONFIG_3;
  MOTOR_OUT_ELEC_t MOTOR_OUT_ELEC;
  MOTOR_OUT_MEC_t MOTOR_OUT_MEC;
  TRANSITION_t TRANSITION;
  MOTOR_ANGLE_SP_t MOTOR_ANGLE_SP;
} can_parser_rx_t;

// There is no any TX mapped massage.

uint32_t can_parser_Receive(can_parser_rx_t* m, const uint8_t* d, uint32_t msgid, uint8_t dlc);

#ifdef __DEF_CAN_PARSER__

extern can_parser_rx_t can_parser_rx;

#endif // __DEF_CAN_PARSER__

#ifdef __cplusplus
}
#endif
