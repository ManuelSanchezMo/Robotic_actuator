#include "can_parser-fmon.h"

#ifdef CAN_PARSER_USE_DIAG_MONITORS

/*
Put the monitor function content here, keep in mind -
next generation will completely clear all manually added code (!)
*/

void FMon_CONFIG_1_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

void FMon_CONFIG_2_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

void FMon_CONFIG_3_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

void FMon_MOTOR_OUT_ELEC_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

void FMon_MOTOR_OUT_MEC_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

void FMon_TRANSITION_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

void FMon_MOTOR_ANGLE_SP_can_parser(FrameMonitor_t* _mon, uint32_t msgid)
{
  (void)_mon;
  (void)msgid;
}

#endif // CAN_PARSER_USE_DIAG_MONITORS
