#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

// DBC file version
#define VER_CAN_PARSER_MAJ (0U)
#define VER_CAN_PARSER_MIN (0U)
#define CAN_PARSER_USE_SIGFLOAT
#define CAN_PARSER_USE_CANSTRUCT
// include current dbc-driver compilation config
#include "can_parser-config.h"

#ifdef CAN_PARSER_USE_DIAG_MONITORS
// This file must define:
// base monitor struct
// function signature for HASH calculation: (@GetFrameHash)
// function signature for getting system tick value: (@GetSystemTick)
#include "canmonitorutil.h"

#endif // CAN_PARSER_USE_DIAG_MONITORS
typedef double sigfloat_t;

// Motor config 1
// def @CONFIG_1 CAN Message (1    0x1)
#define CONFIG_1_IDE (0U)
#define CONFIG_1_DLC (8U)
#define CONFIG_1_CANID (0x1)
// signal: @P_control_ro
#define CAN_PARSER_P_control_ro_CovFactor (0.125000)
#define CAN_PARSER_P_control_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_P_control_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @I_control_ro
#define CAN_PARSER_I_control_ro_CovFactor (0.125000)
#define CAN_PARSER_I_control_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_I_control_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @D_control_ro
#define CAN_PARSER_D_control_ro_CovFactor (0.125000)
#define CAN_PARSER_D_control_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_D_control_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
typedef struct
{
#ifdef CAN_PARSER_USE_CANSTRUCT
  uint32_t MsgId;                     
  uint8_t DLC; 
  uint8_t Data[8] ;
  uint8_t IDE;
  #endif               
} __CoderDbcCanFrame_t__;
typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  int16_t P_control_ro;                      //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t P_control_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t I_control_ro;                      //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t I_control_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t D_control_ro;                      //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t D_control_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#else

  int16_t P_control_ro;                      //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t P_control_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t I_control_ro;                      //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t I_control_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t D_control_ro;                      //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t D_control_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} CONFIG_1_t;

// Motor config 2
// def @CONFIG_2 CAN Message (2    0x2)
#define CONFIG_2_IDE (0U)
#define CONFIG_2_DLC (8U)
#define CONFIG_2_CANID (0x2)
// signal: @P_vel_ro
#define CAN_PARSER_P_vel_ro_CovFactor (0.125000)
#define CAN_PARSER_P_vel_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_P_vel_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @I_vel_ro
#define CAN_PARSER_I_vel_ro_CovFactor (0.125000)
#define CAN_PARSER_I_vel_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_I_vel_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @D_vel_ro
#define CAN_PARSER_D_vel_ro_CovFactor (0.125000)
#define CAN_PARSER_D_vel_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_D_vel_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @Vel_lim_ro
#define CAN_PARSER_Vel_lim_ro_CovFactor (0.125000)
#define CAN_PARSER_Vel_lim_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_Vel_lim_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )

typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  int16_t P_vel_ro;                          //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t P_vel_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t I_vel_ro;                          //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t I_vel_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t D_vel_ro;                          //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t D_vel_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t Vel_lim_ro;                        //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Vel_lim_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#else

  int16_t P_vel_ro;                          //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t P_vel_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t I_vel_ro;                          //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t I_vel_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t D_vel_ro;                          //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t D_vel_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t Vel_lim_ro;                        //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Vel_lim_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} CONFIG_2_t;

// Motor config 3
// def @CONFIG_3 CAN Message (3    0x3)
#define CONFIG_3_IDE (0U)
#define CONFIG_3_DLC (8U)
#define CONFIG_3_CANID (0x3)
// signal: @Volt_lim_ro
#define CAN_PARSER_Volt_lim_ro_CovFactor (0.125000)
#define CAN_PARSER_Volt_lim_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_Volt_lim_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @V_aling_ro
#define CAN_PARSER_V_aling_ro_CovFactor (0.125000)
#define CAN_PARSER_V_aling_ro_toS(x) ( (int16_t) (((x) - (0.000000)) / (0.125000)) )
#define CAN_PARSER_V_aling_ro_fromS(x) ( (((x) * (0.125000)) + (0.000000)) )
// signal: @Zero_angle_elec_ro
#define CAN_PARSER_Zero_angle_elec_ro_CovFactor (0.125000)
#define CAN_PARSER_Zero_angle_elec_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_Zero_angle_elec_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )

typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  int16_t Volt_lim_ro;                       //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Volt_lim_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t V_aling_ro;                        //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t V_aling_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t Calibrate;                         //  [-] Bits=16

  int16_t Zero_angle_elec_ro;                //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Zero_angle_elec_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#else

  int16_t Volt_lim_ro;                       //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Volt_lim_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t V_aling_ro;                        //  [-] Bits=16 Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t V_aling_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t Calibrate;                         //  [-] Bits=16

  int16_t Zero_angle_elec_ro;                //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Zero_angle_elec_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} CONFIG_3_t;

// Motor electric vars feedback
// def @MOTOR_OUT_ELEC CAN Message (4    0x4)
#define MOTOR_OUT_ELEC_IDE (0U)
#define MOTOR_OUT_ELEC_DLC (8U)
#define MOTOR_OUT_ELEC_CANID (0x4)
// signal: @Ua_ro
#define CAN_PARSER_Ua_ro_CovFactor (0.125000)
#define CAN_PARSER_Ua_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_Ua_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )
// signal: @Ub_ro
#define CAN_PARSER_Ub_ro_CovFactor (0.125000)
#define CAN_PARSER_Ub_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_Ub_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )
// signal: @current_ro
#define CAN_PARSER_current_ro_CovFactor (0.125000)
#define CAN_PARSER_current_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_current_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )
// signal: @electrical_angle_ro
#define CAN_PARSER_electrical_angle_ro_CovFactor (0.125000)
#define CAN_PARSER_electrical_angle_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_electrical_angle_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )

typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  int16_t Ua_ro;                             //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Ua_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t Ub_ro;                             //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Ub_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t current_ro;                        //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t current_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t electrical_angle_ro;               //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t electrical_angle_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#else

  int16_t Ua_ro;                             //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Ua_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t Ub_ro;                             //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t Ub_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t current_ro;                        //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t current_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t electrical_angle_ro;               //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t electrical_angle_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} MOTOR_OUT_ELEC_t;

// Motor mecanic vars feedback
// def @MOTOR_OUT_MEC CAN Message (5    0x5)
#define MOTOR_OUT_MEC_IDE (0U)
#define MOTOR_OUT_MEC_DLC (6U)
#define MOTOR_OUT_MEC_CANID (0x5)
// signal: @shaft_angle_ro
#define CAN_PARSER_shaft_angle_ro_CovFactor (0.125000)
#define CAN_PARSER_shaft_angle_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_shaft_angle_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )
// signal: @shaft_angle_sp_ro
#define CAN_PARSER_shaft_angle_sp_ro_CovFactor (0.125000)
#define CAN_PARSER_shaft_angle_sp_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_shaft_angle_sp_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )
// signal: @shaft_velocity_ro
#define CAN_PARSER_shaft_velocity_ro_CovFactor (0.125000)
#define CAN_PARSER_shaft_velocity_ro_toS(x) ( (int16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_shaft_velocity_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )

typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  int16_t shaft_angle_ro;                    //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t shaft_angle_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t shaft_angle_sp_ro;                 //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t shaft_angle_sp_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t shaft_velocity_ro;                 //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t shaft_velocity_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#else

  int16_t shaft_angle_ro;                    //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t shaft_angle_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t shaft_angle_sp_ro;                 //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t shaft_angle_sp_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

  int16_t shaft_velocity_ro;                 //  [-] Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t shaft_velocity_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} MOTOR_OUT_MEC_t;

// Motor set point
// def @TRANSITION CAN Message (7    0x7)
#define TRANSITION_IDE (0U)
#define TRANSITION_DLC (2U)
#define TRANSITION_CANID (0x7)

typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  uint8_t Transition;                        //      Bits= 8

#else

  uint8_t Transition;                        //      Bits= 8

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} TRANSITION_t;

// Motor transition finite state machine
// def @MOTOR_ANGLE_SP CAN Message (7    0x7)
#define MOTOR_ANGLE_SP_IDE (0U)
#define MOTOR_ANGLE_SP_DLC (2U)
#define MOTOR_ANGLE_SP_CANID (0x7)
// signal: @angle_sp_ro
#define CAN_PARSER_angle_sp_ro_CovFactor (0.125000)
#define CAN_PARSER_angle_sp_ro_toS(x) ( (uint16_t) (((x) - (-4095.000000)) / (0.125000)) )
#define CAN_PARSER_angle_sp_ro_fromS(x) ( (((x) * (0.125000)) + (-4095.000000)) )

typedef struct
{
#ifdef CAN_PARSER_USE_BITS_SIGNAL

  uint16_t angle_sp_ro;                      //      Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t angle_sp_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#else

  uint16_t angle_sp_ro;                      //      Bits=16 Offset= -4095.000000       Factor= 0.125000       

#ifdef CAN_PARSER_USE_SIGFLOAT
  sigfloat_t angle_sp_phys;
#endif // CAN_PARSER_USE_SIGFLOAT

#endif // CAN_PARSER_USE_BITS_SIGNAL

#ifdef CAN_PARSER_USE_DIAG_MONITORS

  FrameMonitor_t mon1;

#endif // CAN_PARSER_USE_DIAG_MONITORS

} MOTOR_ANGLE_SP_t;





// Function signatures

uint32_t Unpack_CONFIG_1_can_parser(CONFIG_1_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_CONFIG_1_can_parser(CONFIG_1_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_CONFIG_1_can_parser(CONFIG_1_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_CONFIG_2_can_parser(CONFIG_2_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_CONFIG_2_can_parser(CONFIG_2_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_CONFIG_2_can_parser(CONFIG_2_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_CONFIG_3_can_parser(CONFIG_3_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_CONFIG_3_can_parser(CONFIG_3_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_CONFIG_3_can_parser(CONFIG_3_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_MOTOR_OUT_ELEC_can_parser(MOTOR_OUT_ELEC_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_MOTOR_OUT_ELEC_can_parser(MOTOR_OUT_ELEC_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_MOTOR_OUT_ELEC_can_parser(MOTOR_OUT_ELEC_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_MOTOR_OUT_MEC_can_parser(MOTOR_OUT_MEC_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_MOTOR_OUT_MEC_can_parser(MOTOR_OUT_MEC_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_MOTOR_OUT_MEC_can_parser(MOTOR_OUT_MEC_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_TRANSITION_can_parser(TRANSITION_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_TRANSITION_can_parser(TRANSITION_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_TRANSITION_can_parser(TRANSITION_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_MOTOR_ANGLE_SP_can_parser(MOTOR_ANGLE_SP_t* _m, const uint8_t* _d, uint8_t dlc_);
#ifdef CAN_PARSER_USE_CANSTRUCT
uint32_t Pack_MOTOR_ANGLE_SP_can_parser(MOTOR_ANGLE_SP_t* _m, __CoderDbcCanFrame_t__* cframe);
#else
uint32_t Pack_MOTOR_ANGLE_SP_can_parser(MOTOR_ANGLE_SP_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide);
#endif // CAN_PARSER_USE_CANSTRUCT

#ifdef __cplusplus
}
#endif
