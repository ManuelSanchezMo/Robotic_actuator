#include "can_parser.h"


#ifdef CAN_PARSER_USE_DIAG_MONITORS
// Function prototypes to be called each time CAN frame is unpacked
// FMon function may detect RC, CRC or DLC violation
#include "can_parser-fmon.h"

#endif // CAN_PARSER_USE_DIAG_MONITORS


uint32_t Unpack_CONFIG_1_can_parser(CONFIG_1_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->P_control_ro = ((_d[1] & (0xFFU)) << 8) | (_d[0] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->P_control_phys = (sigfloat_t)(CAN_PARSER_P_control_ro_fromS(_m->P_control_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->I_control_ro = ((_d[3] & (0xFFU)) << 8) | (_d[2] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->I_control_phys = (sigfloat_t)(CAN_PARSER_I_control_ro_fromS(_m->I_control_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->D_control_ro = ((_d[5] & (0xFFU)) << 8) | (_d[4] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->D_control_phys = (sigfloat_t)(CAN_PARSER_D_control_ro_fromS(_m->D_control_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < CONFIG_1_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_CONFIG_1_can_parser(&_m->mon1, CONFIG_1_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return CONFIG_1_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_CONFIG_1_can_parser(CONFIG_1_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < CONFIG_1_DLC) && (i < 8); cframe->Data[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->P_control_ro = CAN_PARSER_P_control_ro_toS(_m->P_control_phys);
  _m->I_control_ro = CAN_PARSER_I_control_ro_toS(_m->I_control_phys);
  _m->D_control_ro = CAN_PARSER_D_control_ro_toS(_m->D_control_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  cframe->Data[0] |= (_m->P_control_ro & (0xFFU));
  cframe->Data[1] |= ((_m->P_control_ro >> 8) & (0xFFU));
  cframe->Data[2] |= (_m->I_control_ro & (0xFFU));
  cframe->Data[3] |= ((_m->I_control_ro >> 8) & (0xFFU));
  cframe->Data[4] |= (_m->D_control_ro & (0xFFU));
  cframe->Data[5] |= ((_m->D_control_ro >> 8) & (0xFFU));

  cframe->MsgId = CONFIG_1_CANID;
  cframe->DLC = CONFIG_1_DLC;
  cframe->IDE = CONFIG_1_IDE;
  return CONFIG_1_CANID;
}

#else

uint32_t Pack_CONFIG_1_can_parser(CONFIG_1_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < CONFIG_1_DLC) && (i < 8); _d[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->P_control_ro = CAN_PARSER_P_control_ro_toS(_m->P_control_phys);
  _m->I_control_ro = CAN_PARSER_I_control_ro_toS(_m->I_control_phys);
  _m->D_control_ro = CAN_PARSER_D_control_ro_toS(_m->D_control_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  _d[0] |= (_m->P_control_ro & (0xFFU));
  _d[1] |= ((_m->P_control_ro >> 8) & (0xFFU));
  _d[2] |= (_m->I_control_ro & (0xFFU));
  _d[3] |= ((_m->I_control_ro >> 8) & (0xFFU));
  _d[4] |= (_m->D_control_ro & (0xFFU));
  _d[5] |= ((_m->D_control_ro >> 8) & (0xFFU));

  *_len = CONFIG_1_DLC;
  *_ide = CONFIG_1_IDE;
  return CONFIG_1_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_CONFIG_2_can_parser(CONFIG_2_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->P_vel_ro = ((_d[1] & (0xFFU)) << 8) | (_d[0] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->P_vel_phys = (sigfloat_t)(CAN_PARSER_P_vel_ro_fromS(_m->P_vel_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->I_vel_ro = ((_d[3] & (0xFFU)) << 8) | (_d[2] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->I_vel_phys = (sigfloat_t)(CAN_PARSER_I_vel_ro_fromS(_m->I_vel_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->D_vel_ro = ((_d[5] & (0xFFU)) << 8) | (_d[4] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->D_vel_phys = (sigfloat_t)(CAN_PARSER_D_vel_ro_fromS(_m->D_vel_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->Vel_lim_ro = ((_d[7] & (0xFFU)) << 8) | (_d[6] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Vel_lim_phys = (sigfloat_t)(CAN_PARSER_Vel_lim_ro_fromS(_m->Vel_lim_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < CONFIG_2_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_CONFIG_2_can_parser(&_m->mon1, CONFIG_2_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return CONFIG_2_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_CONFIG_2_can_parser(CONFIG_2_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < CONFIG_2_DLC) && (i < 8); cframe->Data[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->P_vel_ro = CAN_PARSER_P_vel_ro_toS(_m->P_vel_phys);
  _m->I_vel_ro = CAN_PARSER_I_vel_ro_toS(_m->I_vel_phys);
  _m->D_vel_ro = CAN_PARSER_D_vel_ro_toS(_m->D_vel_phys);
  _m->Vel_lim_ro = CAN_PARSER_Vel_lim_ro_toS(_m->Vel_lim_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  cframe->Data[0] |= (_m->P_vel_ro & (0xFFU));
  cframe->Data[1] |= ((_m->P_vel_ro >> 8) & (0xFFU));
  cframe->Data[2] |= (_m->I_vel_ro & (0xFFU));
  cframe->Data[3] |= ((_m->I_vel_ro >> 8) & (0xFFU));
  cframe->Data[4] |= (_m->D_vel_ro & (0xFFU));
  cframe->Data[5] |= ((_m->D_vel_ro >> 8) & (0xFFU));
  cframe->Data[6] |= (_m->Vel_lim_ro & (0xFFU));
  cframe->Data[7] |= ((_m->Vel_lim_ro >> 8) & (0xFFU));

  cframe->MsgId = CONFIG_2_CANID;
  cframe->DLC = CONFIG_2_DLC;
  cframe->IDE = CONFIG_2_IDE;
  return CONFIG_2_CANID;
}

#else

uint32_t Pack_CONFIG_2_can_parser(CONFIG_2_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < CONFIG_2_DLC) && (i < 8); _d[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->P_vel_ro = CAN_PARSER_P_vel_ro_toS(_m->P_vel_phys);
  _m->I_vel_ro = CAN_PARSER_I_vel_ro_toS(_m->I_vel_phys);
  _m->D_vel_ro = CAN_PARSER_D_vel_ro_toS(_m->D_vel_phys);
  _m->Vel_lim_ro = CAN_PARSER_Vel_lim_ro_toS(_m->Vel_lim_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  _d[0] |= (_m->P_vel_ro & (0xFFU));
  _d[1] |= ((_m->P_vel_ro >> 8) & (0xFFU));
  _d[2] |= (_m->I_vel_ro & (0xFFU));
  _d[3] |= ((_m->I_vel_ro >> 8) & (0xFFU));
  _d[4] |= (_m->D_vel_ro & (0xFFU));
  _d[5] |= ((_m->D_vel_ro >> 8) & (0xFFU));
  _d[6] |= (_m->Vel_lim_ro & (0xFFU));
  _d[7] |= ((_m->Vel_lim_ro >> 8) & (0xFFU));

  *_len = CONFIG_2_DLC;
  *_ide = CONFIG_2_IDE;
  return CONFIG_2_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_CONFIG_3_can_parser(CONFIG_3_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->Volt_lim_ro = ((_d[1] & (0xFFU)) << 8) | (_d[0] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Volt_lim_phys = (sigfloat_t)(CAN_PARSER_Volt_lim_ro_fromS(_m->Volt_lim_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->V_aling_ro = ((_d[3] & (0xFFU)) << 8) | (_d[2] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->V_aling_phys = (sigfloat_t)(CAN_PARSER_V_aling_ro_fromS(_m->V_aling_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->Calibrate = ((_d[5] & (0xFFU)) << 8) | (_d[4] & (0xFFU));
  _m->Zero_angle_elec_ro = ((_d[7] & (0xFFU)) << 8) | (_d[6] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Zero_angle_elec_phys = (sigfloat_t)(CAN_PARSER_Zero_angle_elec_ro_fromS(_m->Zero_angle_elec_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < CONFIG_3_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_CONFIG_3_can_parser(&_m->mon1, CONFIG_3_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return CONFIG_3_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_CONFIG_3_can_parser(CONFIG_3_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < CONFIG_3_DLC) && (i < 8); cframe->Data[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Volt_lim_ro = CAN_PARSER_Volt_lim_ro_toS(_m->Volt_lim_phys);
  _m->V_aling_ro = CAN_PARSER_V_aling_ro_toS(_m->V_aling_phys);
  _m->Zero_angle_elec_ro = CAN_PARSER_Zero_angle_elec_ro_toS(_m->Zero_angle_elec_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  cframe->Data[0] |= (_m->Volt_lim_ro & (0xFFU));
  cframe->Data[1] |= ((_m->Volt_lim_ro >> 8) & (0xFFU));
  cframe->Data[2] |= (_m->V_aling_ro & (0xFFU));
  cframe->Data[3] |= ((_m->V_aling_ro >> 8) & (0xFFU));
  cframe->Data[4] |= (_m->Calibrate & (0xFFU));
  cframe->Data[5] |= ((_m->Calibrate >> 8) & (0xFFU));
  cframe->Data[6] |= (_m->Zero_angle_elec_ro & (0xFFU));
  cframe->Data[7] |= ((_m->Zero_angle_elec_ro >> 8) & (0xFFU));

  cframe->MsgId = CONFIG_3_CANID;
  cframe->DLC = CONFIG_3_DLC;
  cframe->IDE = CONFIG_3_IDE;
  return CONFIG_3_CANID;
}

#else

uint32_t Pack_CONFIG_3_can_parser(CONFIG_3_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < CONFIG_3_DLC) && (i < 8); _d[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Volt_lim_ro = CAN_PARSER_Volt_lim_ro_toS(_m->Volt_lim_phys);
  _m->V_aling_ro = CAN_PARSER_V_aling_ro_toS(_m->V_aling_phys);
  _m->Zero_angle_elec_ro = CAN_PARSER_Zero_angle_elec_ro_toS(_m->Zero_angle_elec_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  _d[0] |= (_m->Volt_lim_ro & (0xFFU));
  _d[1] |= ((_m->Volt_lim_ro >> 8) & (0xFFU));
  _d[2] |= (_m->V_aling_ro & (0xFFU));
  _d[3] |= ((_m->V_aling_ro >> 8) & (0xFFU));
  _d[4] |= (_m->Calibrate & (0xFFU));
  _d[5] |= ((_m->Calibrate >> 8) & (0xFFU));
  _d[6] |= (_m->Zero_angle_elec_ro & (0xFFU));
  _d[7] |= ((_m->Zero_angle_elec_ro >> 8) & (0xFFU));

  *_len = CONFIG_3_DLC;
  *_ide = CONFIG_3_IDE;
  return CONFIG_3_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_MOTOR_OUT_ELEC_can_parser(MOTOR_OUT_ELEC_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->Ua_ro = ((_d[1] & (0xFFU)) << 8) | (_d[0] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Ua_phys = (sigfloat_t)(CAN_PARSER_Ua_ro_fromS(_m->Ua_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->Ub_ro = ((_d[3] & (0xFFU)) << 8) | (_d[2] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Ub_phys = (sigfloat_t)(CAN_PARSER_Ub_ro_fromS(_m->Ub_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->current_ro = ((_d[5] & (0xFFU)) << 8) | (_d[4] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->current_phys = (sigfloat_t)(CAN_PARSER_current_ro_fromS(_m->current_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->electrical_angle_ro = ((_d[7] & (0xFFU)) << 8) | (_d[6] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->electrical_angle_phys = (sigfloat_t)(CAN_PARSER_electrical_angle_ro_fromS(_m->electrical_angle_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < MOTOR_OUT_ELEC_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_MOTOR_OUT_ELEC_can_parser(&_m->mon1, MOTOR_OUT_ELEC_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return MOTOR_OUT_ELEC_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_MOTOR_OUT_ELEC_can_parser(MOTOR_OUT_ELEC_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < MOTOR_OUT_ELEC_DLC) && (i < 8); cframe->Data[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Ua_ro = CAN_PARSER_Ua_ro_toS(_m->Ua_phys);
  _m->Ub_ro = CAN_PARSER_Ub_ro_toS(_m->Ub_phys);
  _m->current_ro = CAN_PARSER_current_ro_toS(_m->current_phys);
  _m->electrical_angle_ro = CAN_PARSER_electrical_angle_ro_toS(_m->electrical_angle_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  cframe->Data[0] |= (_m->Ua_ro & (0xFFU));
  cframe->Data[1] |= ((_m->Ua_ro >> 8) & (0xFFU));
  cframe->Data[2] |= (_m->Ub_ro & (0xFFU));
  cframe->Data[3] |= ((_m->Ub_ro >> 8) & (0xFFU));
  cframe->Data[4] |= (_m->current_ro & (0xFFU));
  cframe->Data[5] |= ((_m->current_ro >> 8) & (0xFFU));
  cframe->Data[6] |= (_m->electrical_angle_ro & (0xFFU));
  cframe->Data[7] |= ((_m->electrical_angle_ro >> 8) & (0xFFU));

  cframe->MsgId = MOTOR_OUT_ELEC_CANID;
  cframe->DLC = MOTOR_OUT_ELEC_DLC;
  cframe->IDE = MOTOR_OUT_ELEC_IDE;
  return MOTOR_OUT_ELEC_CANID;
}

#else

uint32_t Pack_MOTOR_OUT_ELEC_can_parser(MOTOR_OUT_ELEC_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < MOTOR_OUT_ELEC_DLC) && (i < 8); _d[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->Ua_ro = CAN_PARSER_Ua_ro_toS(_m->Ua_phys);
  _m->Ub_ro = CAN_PARSER_Ub_ro_toS(_m->Ub_phys);
  _m->current_ro = CAN_PARSER_current_ro_toS(_m->current_phys);
  _m->electrical_angle_ro = CAN_PARSER_electrical_angle_ro_toS(_m->electrical_angle_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  _d[0] |= (_m->Ua_ro & (0xFFU));
  _d[1] |= ((_m->Ua_ro >> 8) & (0xFFU));
  _d[2] |= (_m->Ub_ro & (0xFFU));
  _d[3] |= ((_m->Ub_ro >> 8) & (0xFFU));
  _d[4] |= (_m->current_ro & (0xFFU));
  _d[5] |= ((_m->current_ro >> 8) & (0xFFU));
  _d[6] |= (_m->electrical_angle_ro & (0xFFU));
  _d[7] |= ((_m->electrical_angle_ro >> 8) & (0xFFU));

  *_len = MOTOR_OUT_ELEC_DLC;
  *_ide = MOTOR_OUT_ELEC_IDE;
  return MOTOR_OUT_ELEC_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_MOTOR_OUT_MEC_can_parser(MOTOR_OUT_MEC_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->shaft_angle_ro = ((_d[1] & (0xFFU)) << 8) | (_d[0] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->shaft_angle_phys = (sigfloat_t)(CAN_PARSER_shaft_angle_ro_fromS(_m->shaft_angle_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->shaft_angle_sp_ro = ((_d[3] & (0xFFU)) << 8) | (_d[2] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->shaft_angle_sp_phys = (sigfloat_t)(CAN_PARSER_shaft_angle_sp_ro_fromS(_m->shaft_angle_sp_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

  _m->shaft_velocity_ro = ((_d[5] & (0xFFU)) << 8) | (_d[4] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->shaft_velocity_phys = (sigfloat_t)(CAN_PARSER_shaft_velocity_ro_fromS(_m->shaft_velocity_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < MOTOR_OUT_MEC_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_MOTOR_OUT_MEC_can_parser(&_m->mon1, MOTOR_OUT_MEC_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return MOTOR_OUT_MEC_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_MOTOR_OUT_MEC_can_parser(MOTOR_OUT_MEC_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < MOTOR_OUT_MEC_DLC) && (i < 8); cframe->Data[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->shaft_angle_ro = CAN_PARSER_shaft_angle_ro_toS(_m->shaft_angle_phys);
  _m->shaft_angle_sp_ro = CAN_PARSER_shaft_angle_sp_ro_toS(_m->shaft_angle_sp_phys);
  _m->shaft_velocity_ro = CAN_PARSER_shaft_velocity_ro_toS(_m->shaft_velocity_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  cframe->Data[0] |= (_m->shaft_angle_ro & (0xFFU));
  cframe->Data[1] |= ((_m->shaft_angle_ro >> 8) & (0xFFU));
  cframe->Data[2] |= (_m->shaft_angle_sp_ro & (0xFFU));
  cframe->Data[3] |= ((_m->shaft_angle_sp_ro >> 8) & (0xFFU));
  cframe->Data[4] |= (_m->shaft_velocity_ro & (0xFFU));
  cframe->Data[5] |= ((_m->shaft_velocity_ro >> 8) & (0xFFU));

  cframe->MsgId = MOTOR_OUT_MEC_CANID;
  cframe->DLC = MOTOR_OUT_MEC_DLC;
  cframe->IDE = MOTOR_OUT_MEC_IDE;
  return MOTOR_OUT_MEC_CANID;
}

#else

uint32_t Pack_MOTOR_OUT_MEC_can_parser(MOTOR_OUT_MEC_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < MOTOR_OUT_MEC_DLC) && (i < 8); _d[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->shaft_angle_ro = CAN_PARSER_shaft_angle_ro_toS(_m->shaft_angle_phys);
  _m->shaft_angle_sp_ro = CAN_PARSER_shaft_angle_sp_ro_toS(_m->shaft_angle_sp_phys);
  _m->shaft_velocity_ro = CAN_PARSER_shaft_velocity_ro_toS(_m->shaft_velocity_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  _d[0] |= (_m->shaft_angle_ro & (0xFFU));
  _d[1] |= ((_m->shaft_angle_ro >> 8) & (0xFFU));
  _d[2] |= (_m->shaft_angle_sp_ro & (0xFFU));
  _d[3] |= ((_m->shaft_angle_sp_ro >> 8) & (0xFFU));
  _d[4] |= (_m->shaft_velocity_ro & (0xFFU));
  _d[5] |= ((_m->shaft_velocity_ro >> 8) & (0xFFU));

  *_len = MOTOR_OUT_MEC_DLC;
  *_ide = MOTOR_OUT_MEC_IDE;
  return MOTOR_OUT_MEC_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_TRANSITION_can_parser(TRANSITION_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->Transition = (_d[0] & (0xFFU));

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < TRANSITION_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_TRANSITION_can_parser(&_m->mon1, TRANSITION_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return TRANSITION_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_TRANSITION_can_parser(TRANSITION_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < TRANSITION_DLC) && (i < 8); cframe->Data[i++] = 0);

  cframe->Data[0] |= (_m->Transition & (0xFFU));

  cframe->MsgId = TRANSITION_CANID;
  cframe->DLC = TRANSITION_DLC;
  cframe->IDE = TRANSITION_IDE;
  return TRANSITION_CANID;
}

#else

uint32_t Pack_TRANSITION_can_parser(TRANSITION_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < TRANSITION_DLC) && (i < 8); _d[i++] = 0);

  _d[0] |= (_m->Transition & (0xFFU));

  *_len = TRANSITION_DLC;
  *_ide = TRANSITION_IDE;
  return TRANSITION_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

uint32_t Unpack_MOTOR_ANGLE_SP_can_parser(MOTOR_ANGLE_SP_t* _m, const uint8_t* _d, uint8_t dlc_)
{
  (void)dlc_;
  _m->angle_sp_ro = ((_d[1] & (0xFFU)) << 8) | (_d[0] & (0xFFU));
#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->angle_sp_phys = (sigfloat_t)(CAN_PARSER_angle_sp_ro_fromS(_m->angle_sp_ro));
#endif // CAN_PARSER_USE_SIGFLOAT

#ifdef CAN_PARSER_USE_DIAG_MONITORS
  _m->mon1.dlc_error = (dlc_ < MOTOR_ANGLE_SP_DLC);
  _m->mon1.last_cycle = GetSystemTick();
  _m->mon1.frame_cnt++;

  FMon_MOTOR_ANGLE_SP_can_parser(&_m->mon1, MOTOR_ANGLE_SP_CANID);
#endif // CAN_PARSER_USE_DIAG_MONITORS

  return MOTOR_ANGLE_SP_CANID;
}

#ifdef CAN_PARSER_USE_CANSTRUCT

uint32_t Pack_MOTOR_ANGLE_SP_can_parser(MOTOR_ANGLE_SP_t* _m, __CoderDbcCanFrame_t__* cframe)
{
  uint8_t i; for (i = 0; (i < MOTOR_ANGLE_SP_DLC) && (i < 8); cframe->Data[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->angle_sp_ro = CAN_PARSER_angle_sp_ro_toS(_m->angle_sp_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  cframe->Data[0] |= (_m->angle_sp_ro & (0xFFU));
  cframe->Data[1] |= ((_m->angle_sp_ro >> 8) & (0xFFU));

  cframe->MsgId = MOTOR_ANGLE_SP_CANID;
  cframe->DLC = MOTOR_ANGLE_SP_DLC;
  cframe->IDE = MOTOR_ANGLE_SP_IDE;
  return MOTOR_ANGLE_SP_CANID;
}

#else

uint32_t Pack_MOTOR_ANGLE_SP_can_parser(MOTOR_ANGLE_SP_t* _m, uint8_t* _d, uint8_t* _len, uint8_t* _ide)
{
  uint8_t i; for (i = 0; (i < MOTOR_ANGLE_SP_DLC) && (i < 8); _d[i++] = 0);

#ifdef CAN_PARSER_USE_SIGFLOAT
  _m->angle_sp_ro = CAN_PARSER_angle_sp_ro_toS(_m->angle_sp_phys);
#endif // CAN_PARSER_USE_SIGFLOAT

  _d[0] |= (_m->angle_sp_ro & (0xFFU));
  _d[1] |= ((_m->angle_sp_ro >> 8) & (0xFFU));

  *_len = MOTOR_ANGLE_SP_DLC;
  *_ide = MOTOR_ANGLE_SP_IDE;
  return MOTOR_ANGLE_SP_CANID;
}

#endif // CAN_PARSER_USE_CANSTRUCT

